import 'package:flutter/material.dart';

void main() {
  runApp(SRVoiceChatApp());
}

class SRVoiceChatApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'SR Voice Chat',
      home: VoiceHome(),
    );
  }
}

class VoiceHome extends StatefulWidget {
  @override
  _VoiceHomeState createState() => _VoiceHomeState();
}

class _VoiceHomeState extends State<VoiceHome> {
  bool isRecording = false;
  List<String> messages = ["Welcome to SR Voice Chat! 🎤"];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xFF1A1A2E),
      appBar: AppBar(
        title: Text("SR VOICE CHAT", style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.deepPurple,
        centerTitle: true,
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              padding: EdgeInsets.all(10),
              itemCount: messages.length,
              itemBuilder: (context, i) => Container(
                margin: EdgeInsets.symmetric(vertical: 5),
                padding: EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.deepPurple.withOpacity(0.3),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Row(
                  children: [
                    Icon(Icons.mic, color: Colors.white70),
                    SizedBox(width: 10),
                    Expanded(child: Text(messages[i], style: TextStyle(color: Colors.white))),
                  ],
                ),
              ),
            ),
          ),
          Divider(color: Colors.white24),
          Padding(
            padding: EdgeInsets.all(20),
            child: Column(
              children: [
                GestureDetector(
                  onTap: () {
                    setState(() {
                      isRecording = !isRecording;
                      if (isRecording) {
                        messages.add("🎙️ Recording... ${DateTime.now().second}s");
                      } else {
                        messages.add("✅ Voice Sent! - ${messages.length}");
                      }
                    });
                  },
                  child: Container(
                    height: 80,
                    width: 80,
                    decoration: BoxDecoration(
                      color: isRecording ? Colors.red : Colors.deepPurple,
                      shape: BoxShape.circle,
                      boxShadow: [BoxShadow(color: Colors.deepPurple.withOpacity(0.5), blurRadius: 10)],
                    ),
                    child: Icon(isRecording ? Icons.stop : Icons.mic, size: 40, color: Colors.white),
                  ),
                ),
                SizedBox(height: 10),
                Text(isRecording ? "Tap to Stop Recording" : "Tap to Speak",
                    style: TextStyle(color: Colors.white70)),
                SizedBox(height: 20),
              ],
            ),
          ),
        ],
      ),
    );
  }
}